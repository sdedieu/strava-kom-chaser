import {Component, inject, OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AppInitService} from './core/app-init.service';
import {StravaService} from './core/strava.service';
import {Opportunity} from './models';

@Component({
  selector:'app-root',
  standalone:true,
  imports:[CommonModule],
  templateUrl:'./app.component.html',
  styleUrl:'./app.component.css'
})
export class AppComponent implements OnInit {
  private init = inject(AppInitService);
  private strava = inject(StravaService);

  connected = false;
  athlete = '';
  busy = false;
  message = '';
  rows: Opportunity[] = [];

  async ngOnInit() {
    await this.init.init();
    this.refreshStatus();
  }

  refreshStatus() {
    this.strava.status().subscribe({
      next:s => {
        this.connected=s.connected;
        this.athlete=s.athlete ? `${s.athlete.firstname} ${s.athlete.lastname}` : '';
      },
      error:e => this.message=e.message || 'Unable to check Strava.'
    });
  }

  connect() {
    this.strava.startOAuth().subscribe(url => location.href=url);
  }

  sync() {
    this.busy=true; this.message='Syncing your recent rides…';
    this.strava.sync().subscribe({
      next:r=>{this.message=`Imported ${r.activities} rides and ${r.observations} segment observations.`;this.busy=false;},
      error:e=>{this.message=e.message||'Sync failed.';this.busy=false;}
    });
  }

  discover() {
    this.busy=true; this.message='Discovering and scoring segments…';
    // Example geographic box. Replace with map-drawn bounds.
    this.strava.discover([41.34,2.00,41.48,2.25]).subscribe({
      next:r=>{this.rows=r;this.message=`Found ${r.length} candidate segments.`;this.busy=false;},
      error:e=>{this.message=e.message||'Discovery failed.';this.busy=false;}
    });
  }

  fmt(sec:number) {
    sec=Math.max(0,Math.round(sec));
    return `${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`;
  }
}