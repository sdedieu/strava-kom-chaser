import { Injectable, inject } from '@angular/core';
import { Auth, signInAnonymously } from '@angular/fire/auth';

@Injectable({providedIn: 'root'})
export class AppInitService {
  private auth = inject(Auth);
  async init() {
    if (!this.auth.currentUser) await signInAnonymously(this.auth);
  }
}