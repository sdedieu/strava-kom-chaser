import { Injectable, inject } from '@angular/core';
import { Functions, httpsCallable } from '@angular/fire/functions';
import { from } from 'rxjs';
import { Opportunity } from '../models';

@Injectable({providedIn: 'root'})
export class StravaService {
  private functions = inject(Functions);

  startOAuth() {
    const fn = httpsCallable<void, {url:string}>(this.functions, 'stravaOAuthUrl');
    return from(fn({}).then(r => r.data.url));
  }

  status() {
    const fn = httpsCallable<void, {connected:boolean; athlete?: any}>(this.functions, 'stravaStatus');
    return from(fn({}).then(r => r.data));
  }

  sync() {
    const fn = httpsCallable<void, any>(this.functions, 'syncStravaData');
    return from(fn({}).then(r => r.data));
  }

  discover(bounds: [number,number,number,number]) {
    const fn = httpsCallable<{bounds:number[]}, Opportunity[]>(this.functions, 'discoverKOMOpportunities');
    return from(fn({bounds}).then(r => r.data));
  }
}