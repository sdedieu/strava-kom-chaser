import {onCall,onRequest,HttpsError} from 'firebase-functions/v2/https';
import {defineSecret} from 'firebase-functions/params';
import {initializeApp} from 'firebase-admin/app';
import {getFirestore,FieldValue} from 'firebase-admin/firestore';
import crypto from 'node:crypto';

initializeApp();
const db=getFirestore();
const CLIENT_ID=defineSecret('STRAVA_CLIENT_ID');
const CLIENT_SECRET=defineSecret('STRAVA_CLIENT_SECRET');
const API='https://www.strava.com/api/v3';
const OAUTH='https://www.strava.com/oauth';
const APP_URL='https://YOUR_PROJECT.web.app';
const REGION='europe-west1';

type Token={access_token:string;refresh_token:string;expires_at:number;athlete:any};
type Effort={id:number;elapsed_time:number;average_watts?:number;segment:{id:number;name:string;distance:number;average_grade:number;total_elevation_gain:number}};
type Activity={id:number;sport_type?:string;type?:string;segment_efforts?:Effort[]};

async function api<T>(path:string,token:string):Promise<T>{
  const r=await fetch(API+path,{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok) throw new Error(`Strava ${r.status}: ${await r.text()}`);
  return r.json() as Promise<T>;
}
function uid(req:any){if(!req.auth?.uid)throw new HttpsError('unauthenticated','Sign in first.');return req.auth.uid;}
async function tokens(id:string):Promise<Token>{
  const s=await db.doc(`stravaTokens/${id}`).get();
  if(!s.exists)throw new HttpsError('failed-precondition','Connect Strava first.');
  const t=s.data() as Token;
  if(t.expires_at>Date.now()/1000+120)return t;
  const r=await fetch(`${OAUTH}/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({
    client_id:CLIENT_ID.value(),client_secret:CLIENT_SECRET.value(),grant_type:'refresh_token',refresh_token:t.refresh_token
  })});
  if(!r.ok)throw new HttpsError('internal','Could not refresh Strava token.');
  const n=await r.json() as Token;
  await db.doc(`stravaTokens/${id}`).set({...t,...n},{merge:true});
  return {...t,...n};
}
function state(uid:string){
  const payload=Buffer.from(JSON.stringify({uid,exp:Date.now()+600000})).toString('base64url');
  const sig=crypto.createHmac('sha256',CLIENT_SECRET.value()).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
function verify(s:string){
  const [p,sig]=s.split('.');
  if(!p||!sig)throw new Error('Invalid state');
  const expected=crypto.createHmac('sha256',CLIENT_SECRET.value()).update(p).digest('base64url');
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))throw new Error('Invalid state');
  const x=JSON.parse(Buffer.from(p,'base64url').toString());
  if(x.exp<Date.now())throw new Error('Expired state');
  return x as {uid:string};
}

export const stravaOAuthUrl=onCall({secrets:[CLIENT_SECRET,CLIENT_ID],region:REGION},async req=>{
  const id=uid(req);
  const callback=`https://${REGION}-${process.env.GCLOUD_PROJECT}.cloudfunctions.net/stravaOAuthCallback`;
  const q=new URLSearchParams({client_id:CLIENT_ID.value(),redirect_uri:callback,response_type:'code',approval_prompt:'auto',scope:'read,activity:read',state:state(id)});
  return {url:`${OAUTH}/authorize?${q}`};
});

export const stravaOAuthCallback=onRequest({secrets:[CLIENT_SECRET,CLIENT_ID],region:REGION},async(req,res)=>{
  try{
    const {uid:id}=verify(String(req.query.state||''));
    const code=String(req.query.code||'');
    const callback=`https://${REGION}-${process.env.GCLOUD_PROJECT}.cloudfunctions.net/stravaOAuthCallback`;
    const r=await fetch(`${OAUTH}/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({
      client_id:CLIENT_ID.value(),client_secret:CLIENT_SECRET.value(),code,grant_type:'authorization_code',redirect_uri:callback
    })});
    if(!r.ok)throw new Error(await r.text());
    const t=await r.json() as Token;
    await db.doc(`stravaTokens/${id}`).set({access_token:t.access_token,refresh_token:t.refresh_token,expires_at:t.expires_at,athlete:t.athlete,updatedAt:FieldValue.serverTimestamp()});
    res.redirect(`${APP_URL}/?strava=connected`);
  }catch(e){console.error(e);res.status(400).send('Strava authorization failed.');}
});

export const stravaStatus=onCall({region:REGION},async req=>{
  const id=uid(req);const s=await db.doc(`stravaTokens/${id}`).get();
  return s.exists?{connected:true,athlete:s.data()?.athlete}:{connected:false};
});

export const syncStravaData=onCall({region:REGION,secrets:[CLIENT_ID,CLIENT_SECRET]},async req=>{
  const id=uid(req),t=await tokens(id);
  const activities:Activity[]=[];
  for(let page=1;page<=2;page++){
    const batch=await api<Activity[]>(`/athlete/activities?page=${page}&per_page=50`,t.access_token);
    activities.push(...batch.filter(a=>(a.sport_type||a.type)==='Ride'));
    if(batch.length<50)break;
  }
  const observations:any[]=[];
  for(const a of activities){
    const d=await api<Activity>(`/activities/${a.id}?include_all_efforts=true`,t.access_token);
    for(const e of d.segment_efforts||[]){
      if(e.segment?.id)observations.push({segmentId:e.segment.id,elapsedTime:e.elapsed_time,watts:e.average_watts,grade:e.segment.average_grade,distance:e.segment.distance});
    }
  }
  await db.doc(`users/${id}/performance/profile`).set({observations:observations.slice(0,3000),activityCount:activities.length,updatedAt:FieldValue.serverTimestamp()});
  return {activities:activities.length,observations:observations.length};
});

export const discoverKOMOpportunities=onCall({region:REGION,secrets:[CLIENT_ID,CLIENT_SECRET]},async req=>{
  const id=uid(req),t=await tokens(id);
  const b=(req.data?.bounds||[41.34,2,41.48,2.25]) as number[];
  const q=new URLSearchParams({bounds:b.join(','),activity_type:'riding',max_cat:'5'});
  const found=await api<any[]>(`/segments/explore?${q}`,t.access_token);
  const details=await Promise.all(found.map(x=>api<any>(`/segments/${x.id}`,t.access_token)));
  const p=await db.doc(`users/${id}/performance/profile`).get();
  const obs=(p.data()?.observations||[]) as any[];
  return details.map(s=>score(s,obs)).sort((a,b)=>b.score-a.score);
});

function score(s:any,obs:any[]){
  const kom=s.kom?.elapsed_time||s.xoms?.kom?.effort?.elapsed_time||0;
  const similar=obs.filter(o=>Math.abs(o.grade-s.average_grade)<2.5&&Math.abs(o.distance-s.distance)/Math.max(s.distance,1)<.25);
  let predicted=0;
  if(similar.length){
    const vals=similar.map(o=>o.elapsedTime*s.distance/Math.max(o.distance,1)).sort((a,b)=>a-b);
    predicted=vals[Math.floor(vals.length/2)];
  }else{
    const usable=obs.filter(o=>o.distance>200&&o.elapsedTime>30);
    const speeds=usable.map(o=>o.distance/o.elapsedTime).sort((a,b)=>a-b);
    predicted=s.distance/(speeds[Math.floor(speeds.length/2)]||6);
  }
  const margin=kom-predicted;
  const confidence=Math.min(95,30+similar.length*5);
  const score=Math.max(0,Math.min(99,50+(margin/Math.max(kom,1))*1000*(confidence/100)));
  return {id:s.id,name:s.name,distance:s.distance,averageGrade:s.average_grade,elevationGain:s.total_elevation_gain,komTime:kom,predictedTime:predicted,marginSeconds:margin,score,confidence};
}